# Import necessary libraries
from flask import Flask, render_template, request, jsonify  # Flask is used for creating a web application
import cv2  # OpenCV library for computer vision
import numpy as np  # NumPy for numerical operations
import torch  # PyTorch for deep learning
from PIL import Image  # Python Imaging Library for image manipulation
import sys  # System-specific parameters and functions
import os  # Operating system interfaces
import numpy as np  # NumPy for numerical operations
from pathlib import Path  # Path manipulation for file handling
from typing import Union  # Type hinting for function parameters
import cv2  # OpenCV library for computer vision
from ultralytics import YOLO  # Ultralytics YOLO for object detection
import requests  # HTTP library for making requests
import base64  # Encoding and decoding binary data as base64
import cv2  # OpenCV library for computer vision
import screeninfo  # Library for screen information retrieval
import time  # Time-related functions
import math  # Mathematical functions
import openai  # OpenAI's GPT-3 library for natural language processing
from flask import Flask, jsonify, request  # Flask for creating a web application
import threading  # Threading for parallel execution

# Create a Flask web application instance
app = Flask(__name__)

# Define the OpenAI GPT-3 model and API key
MODEL = "gpt-3.5-turbo"  # Specify the GPT-3 model to use
openai.api_key = "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"  # Your OpenAI API key

# Define class names for object detection
names=[ 'short sleeve top', 'long sleeve top','short sleeve outwear','long sleeve outwear',
         'vest','sling','shorts','trousers','skirt','short sleeve dress','long sleeve dress',
         'vest dress','sling dress' ]  # List of class names for object detection

# Define Baidu AI credentials for face recognition
client_id = 'lWqM4FR09C71ZtDpb5fxxscA'  # Baidu AI client ID
client_secret = 'hvxH0LMw0GYeqIpWtKlF7x6bredpFbBc'  # Baidu AI client secret

# Function to get Baidu AI access token
def get_access_token(client_id, client_secret):
    # Create a URL for obtaining the access token using Baidu AI credentials
    host = 'https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=' + client_id + '&client_secret=' + client_secret
    
    # Set the header for the request
    header = {'Content-Type': 'application/json; charset=UTF-8'}
    
    # Send a POST request to obtain the access token
    response1 = requests.post(url=host, headers=header)
    
    # Parse the JSON response to extract the access token
    json1 = response1.json()
    access_token = json1['access_token']
    return access_token

# Function to convert an image to base64 format
def open_pic2base64(path):
    # Open the image file at the specified path in binary read mode
    f = open(path, 'rb')
    
    # Read the image file and encode it as base64
    img = base64.b64encode(f.read()).decode('utf-8')
    return img

# Function to perform face recognition using Baidu AI
def bd_rec_face(client_id, client_secret, path):
    # Define the URL for Baidu AI face recognition API
    request_url = "https://aip.baidubce.com/rest/2.0/face/v3/detect"
    
    # Define the parameters for the API request, including the image in base64 format
    params = {"image": open_pic2base64(path), "image_type": "BASE64",
              "face_field": "age,beauty,glasses,gender,race,emotion"}
    
    # Define the header for the HTTP request
    header = {'Content-Type': 'application/json'}

    # Get the Baidu AI access token using the provided credentials
    access_token = get_access_token(client_id, client_secret)
    
    # Append the access token to the request URL
    request_url = request_url + "?access_token=" + access_token
    
    # Send a POST request to perform face recognition
    request_url = request_url + "?access_token=" + access_token
    response1 = requests.post(url=request_url, data=params, headers=header)
    
    # Parse the JSON response to extract gender, age, and emotion information
    json1 = response1.json()
    gender = json1["result"]["face_list"][0]['gender']['type']
    age = json1["result"]["face_list"][0]['age']
    emotion = json1["result"]["face_list"][0]['emotion']['type']
    return gender, age, emotion

# Define the default route for the web application
@app.route('/')
def index():
    return render_template('index.html')

# Initialize variables for gender, age, emotion, and recommendation
gender = None
age = None
emotion = None
timer = 0
recommend = " "

# Function to start a new thread for asking questions to the GPT-3 model
def start_thread(question):
    thread = threading.Thread(target=ask, args=(question,))
    thread.start()

# Function to ask a question to the GPT-3 model
def ask(question):
    # Create a conversation with a system message and user input
    response = openai.ChatCompletion.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You are a fashion stylist and your answers must be within 50 words."},
            {"role": "user", "content": question},
        ],
        temperature=0,  # Temperature parameter for response randomness (0 means deterministic)
    )
    
    # Extract the generated response from GPT-3
    result = response["choices"][0]["message"]["content"]
    global recommend
    recommend = result
    print(result)
    return result

# Function to perform object detection and face recognition
def detection(frame):
    # Initialize the YOLO model for object detection
    model = YOLO(r"D:\Project\DeepFashion\ultralytics-main\ultralytics-main\runs\detect\train17\weights\best.pt")
    flag = 0
    
    # Initialize global variables for gender, age, emotion, and timer
    global gender, age, emotion, timer
    
    # Initialize lists for detected labels and bounding boxes
    Lable = []
    bounding = []
    
    # Perform object detection using YOLO
    results = model(frame, stream=True)
    for r in results:
        boxes = r.boxes
        for box in boxes:
            # Extract bounding box coordinates
            x1, y1, x2, y2 = box.xyxy[0]
            x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
            
            # Extract confidence score
            confidence = math.ceil((box.conf[0] * 100)) / 100
            print("Confidence --->", confidence)
            
            # Extract class name
            cls = int(box.cls[0])
            print("Class name -->", names[cls])
            
            # Check if the confidence score is above a threshold (e.g., 0.5)
            if confidence > 0.5:
                # Add the class name to the list of detected labels
                Lable.append(names[cls])
                
                # Add the bounding box coordinates to the list of bounding boxes
                bounding.append([int(x1), int(y1), int(x2 - x1), int(y2 - y1)])
    
    # Perform face recognition if enough time has passed and labels are detected
    if time.time() - timer > 30 and len(Lable) > 0:
        # Save the current frame as an image
        cv2.imwrite("frame.jpg", frame)
        try:
            # Perform face recognition using Baidu AI and get gender, age, and emotion information
            gender, age, emotion = bd_rec_face(client_id, client_secret, "frame.jpg")
        except Exception as r:
            print("Skip ")
        
        # Create a question based on detected information for GPT-3
        question = "I am"
        if age != None:
            question += " " + str(age) + " years old"
        if gender != None:
            question += " " + gender
        if emotion != None:
            question += " feeling " + emotion
        question += ' and wearing '
        for lb in Lable:
            question += ', ' + lb
        question += ". Please give me a styling suggestion."
        print(question)
        
        # Start a new thread to ask the question to GPT-3
        start_thread(question)
        
        # Update the timer
        timer = time.time()
        print(Lable, bounding)
    
    # Return detected labels, bounding boxes, and GPT-3 recommendation
    return {
        "label": Lable,
        "bounding": bounding,
        "recommend": recommend
    }

# Define the route for processing uploaded images
@app.route('/process_image', methods=['POST'])
def process_image():
    # Get the uploaded image file from the request
    file = request.files['image']
    
    # Read the image file and decode it into an OpenCV image
    filestr = file.read()
    npimg = np.fromstring(filestr, np.uint8)
    img = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
    
    # Perform object detection and face recognition on the image
    result = detection(img)
    
    # Return the result as JSON
    return jsonify(result)

# Run the Flask web application
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
